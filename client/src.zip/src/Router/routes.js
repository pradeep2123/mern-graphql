const router = {
  show: "/show",
  create: "/create"
};

module.exports = {
  router: router
};
